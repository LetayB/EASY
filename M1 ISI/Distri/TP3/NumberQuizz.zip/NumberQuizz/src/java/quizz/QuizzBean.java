package quizz;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.AbortProcessingException;
import javax.faces.event.ValueChangeEvent;

@ManagedBean
@SessionScoped
public class QuizzBean implements Serializable {

    private final List<Problem> problems = new ArrayList<>(); // Les problèmes
    private int index; // Index du problème courant
    private int score; // Score du joueur
    private int answer; // Réponse du joueur

    public QuizzBean() {
	problems.add(new Problem(new int[] {3, 1, 4, 1, 5}, 9)); // Pi
	problems.add(new Problem(new int[] {0, 1, 1, 2, 3}, 5)); // Fibonacci
	problems.add(new Problem(new int[] {1, 4, 9, 16, 25}, 36)); // Carré
	problems.add(new Problem(new int[] {1, 3, 5, 7, 9}, 11)); // Premiers
	problems.add(new Problem(new int[] {1, 2, 4, 8, 16}, 32)); // Puissance de 2
	index = 0;
	score = 0;
    }

    public int getScore() {
	return score;
    }

    public int getAnswer() {
	return -1;
    }

    public void setAnswer(int answer) {
	this.answer = answer;
    }

    public Problem getCurrentProblem() {
	return problems.get(index);
    }

    // Listener appelé après la validation (phase 3) mais avant la modification du modèle (phase 4)
    public void answerListener(ValueChangeEvent event) throws AbortProcessingException {
	int newValue = (int)event.getNewValue();
	if (this.getCurrentProblem().getSolution() == newValue) score++;
    }

    // Méthode appelée en phase 5
    public String nextAction() {
	index++;
	if (index == problems.size())
	    return "result";
	return "";
    }

    // Méthode appelée en phase 5
    public String doItAgainAction() {
	score = 0;
	index = 0;
	return "doItAgain";
    }

}