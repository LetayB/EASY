package quizz;

import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.convert.Converter;
import javax.faces.convert.ConverterException;
import javax.faces.convert.FacesConverter;

@FacesConverter(value="answerConverter")
public class AnswerConverter implements Converter {

    @Override
    public Object getAsObject(FacesContext context, UIComponent component, String value) {
	int intValue;
	try {
	    intValue = Integer.parseInt(value);
	} catch (NumberFormatException nfe) {
	    throw new ConverterException();
	}
	return intValue;
    }

    @Override
    public String getAsString(FacesContext context, UIComponent component, Object value) {
	return "";
    }

}
